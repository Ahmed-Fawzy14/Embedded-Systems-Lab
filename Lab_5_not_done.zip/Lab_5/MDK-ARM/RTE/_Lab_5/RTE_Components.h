
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'Lab_5' 
 * Target:  'Lab_5' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H



#endif /* RTE_COMPONENTS_H */
