lr 5\startup_stm32l432xx.o: startup_stm32l432xx.s
