/* This program blinks the red LED on the
* TI Tiva LaunchPad. The connections are:
* PF1 - red LED
* PF2 - blue LED
* PF3 - green LED
* They are high active (a '1' turns on the LED).
*/
#include "TM4C123GH6PM.h"
#include <stdio.h>
#define SW1 0x10 // PF4
#define SW2 0x01 // PF0
#define LEDS 0x0E // PF1|PF2|PF3
#define RED 0x02
#define BLUE 0x04
#define GREEN 0x08
#define IS_FLASHING 0x10
#define NOT_FLASHING 0x0


uint32_t state = RED;
uint32_t flashing_state = NOT_FLASHING;

// delay in milliseconds (16 MHz CPU clock)
void delay(uint32_t ms_n){
uint32_t ticks_n = (ms_n * 16000);
SysTick->LOAD = ticks_n;
SysTick->CTRL = 0x5; /*Enable the timer and choose sysclk */
while((SysTick->CTRL & 0x10000) == 0) /*wait until the Count flag is set */
{ }
SysTick->CTRL = 0; /*Stop the timer (Enable = 0) */
}

int main(void)
{




	
	//step1: enable clock to GPIOF at clock gating control register
	SYSCTL->RCGCGPIO |= 0x20;
	
	// step 2: unlock PF0	GPIOLOCK and GPIOcommit register
	GPIOF->LOCK = 0x4c4f434b;
	GPIOF->CR = 0x1;
	
	// step 4: enable the GPIO pins for the LED (PF3, 2 1) as output
	//OR when you wan to make smth 1 and AND when you want to make smth 0
	//00001110: unchanged,unchanged,unchanged, unchanged, output, out, out, unchanged
	//11101110: unchanged,unchanged,unchanged, input, unchanged,unchanged,unchanged, in
	GPIOF->DIR |= 0x0e; //00001110
	GPIOF->DIR &= 0xee; // 11101110  -> PF4 sw1 and PF0 sw2 as input
	
	// step 5: enable the GPIO pins for digital function
	GPIOF->DEN |= 0x1F;  //00011111
	
	//step 6 :active low? enable pull up resistor GPIOPUR
	GPIOF ->PUR = 0x11; //00010001 PF0 and PF4 pins enable
	
	GPIOF->AFSEL = 0x0;
	
	
	
	GPIOF->DATA = RED; // turn on blue LED



	while(1)
{
    
    if ((GPIOF->DATA & SW2) == 0) {
        flashing_state = (flashing_state == IS_FLASHING) ?
                          NOT_FLASHING : IS_FLASHING;

        while ((GPIOF->DATA & SW2) == 0);  // wait release
    }


    if ((GPIOF->DATA & SW1) == 0) {

        switch (state) {
            case RED:   state = BLUE; break;
            case BLUE:  state = GREEN; break;
            case GREEN: state = RED; break;
            default:    state = RED; break;
        }

        while ((GPIOF->DATA & SW1) == 0);  // wait release
    }


    if (flashing_state == NOT_FLASHING) {
        GPIOF->DATA = state;  // solid
    }
    else {
        GPIOF->DATA = state;
        delay(250);
        GPIOF->DATA = 0x00;
        delay(250);
    }
}	
						
					
				
		}		
	
