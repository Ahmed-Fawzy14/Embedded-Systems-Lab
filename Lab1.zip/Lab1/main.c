/* This program blinks the red LED on the
* TI Tiva LaunchPad. The connections are:
* PF1 - red LED
* PF2 - blue LED
* PF3 - green LED
* They are high active (a '1' turns on the LED).
*/
#include "TM4C123GH6PM.h"
void delay(uint32_t);
int main(void)
{
	
int SW1 = GPIOF->DATA = 0x0;
	//step1: enable clock to GPIOF at clock gating control register
	SYSCTL->RCGCGPIO |= 0x20;
	
	// step 2: unlock PF0	GPIOLOCK and GPIOcommit register
	GPIOF->LOCK = 0x4c4f434b;
	GPIOF->CR = 0x1;
	
	// step 4: enable the GPIO pins for the LED (PF3, 2 1) as output
	//OR when you wan to make smth 1 and AND when you want to make smth 0
	//00001110: unchanged,unchanged,unchanged, unchanged, output, out, out, unchanged
	//11101110: unchanged,unchanged,unchanged, input, unchanged,unchanged,unchanged, in
	GPIOF->DIR |= 0x0e; //00001110
	GPIOF->DIR &= 0xee; // 11101110  -> PF4 sw1 and PF0 sw2 as input
	
	// step 5: enable the GPIO pins for digital function
	GPIOF->DEN |= 0x1F;  //00011111
	
	//step 6 :active low enable pull up resistor GPIOPUR
	GPIOF ->PUR = 0x1;
	
	GPIOF->AFSEL = 0x0;
	
	
	
	GPIOF->DATA = 0x04; // turn on blue LED

int const REDP = 0x02;
int const BLUEP = 0x04;

int const GREENP = 0x08;
int const BLUENP = 0x14;

while(1)
{	
	
	//00001000 | 00000100 | 00000010
	switch(GPIOF->DATA){
		case(REDP):
			GPIOF->DATA = BLUENP;
		break;

	}
	GPIOF->DATA= 0x04; // turn on red LED
	delay(250);
	GPIOF->DATA = 0x00; // turn off red LED
	delay(250);

}

}
// delay in milliseconds (16 MHz CPU clock)
void delay(uint32_t ms_n)
{
uint32_t ticks_n = (ms_n * 16000);
SysTick->LOAD = ticks_n;
SysTick->CTRL = 0x5; /*Enable the timer and choose sysclk */
while((SysTick->CTRL & 0x10000) == 0) /*wait until the Count flag is set */
{ }
SysTick->CTRL = 0; /*Stop the timer (Enable = 0) */
}