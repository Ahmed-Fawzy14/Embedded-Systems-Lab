.\objects\main.o: main.c
.\objects\main.o: main.h
